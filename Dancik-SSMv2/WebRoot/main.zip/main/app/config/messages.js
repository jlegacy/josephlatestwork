//Defines the front-end soft-coded messages to be loaded at startup
//The path to dws may need to be updated, depending on how the application is deployed.
//$App.Messages('../dws/',[
//	'global.*',
//	'mynav.*'
//]);

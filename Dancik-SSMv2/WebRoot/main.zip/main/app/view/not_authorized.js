(function ($) {
	$App.View('NotAuthorized', {

		// ------------------------------------------------------------
		// -- 
		// ------------------------------------------------------------
		initialize: function () {},
		
		// ------------------------------------------------------------
		// -- Renders the initial application layout
		// ------------------------------------------------------------
		renderApp: function (data) {
			var _this = this;

			var template = $App.Template("not_authorized/base.ejs");
			$j('#app').html(template.render(data));
			
		}
	});
})(jQuery);